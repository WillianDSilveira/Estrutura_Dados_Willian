package Calculadora;

public class CalculadoraTest {

	public static void main(String[] args) {
		Calculadora calculadora = new Calculadora();
		calculadora.lerDados();
		calculadora.realizarOperacao();
	}

}
